package com.example.wedsnap20.ui.screens

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.wedsnap20.services.AuthService
import com.google.firebase.auth.FirebaseAuth

@Composable
fun AccountTypeChoiceScreen(navController: NavController) {
    val context = LocalContext.current
    val authService = AuthService(context)
    val user = FirebaseAuth.getInstance().currentUser

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "What Would You Like To Do?",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            Button(
                onClick = {
                    user?.let {
                        authService.createOrUpdateUser(
                            user = it,
                            name = it.displayName ?: "Anonymous Host",
                            type = "host",
                            onSuccess = {
                                navController.navigate("create_event") {
                                    popUpTo("welcome") { inclusive = true }
                                }
                            },
                            onFailure = { error ->
                                Log.e("AccountTypeChoice", "Failed to save host user", error)
                            }
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text(text = "➕ Create a New Event")
            }

            Button(
                onClick = {
                    user?.let {
                        authService.createOrUpdateUser(
                            user = it,
                            name = it.displayName ?: "Anonymous Guest",
                            type = "guest",
                            onSuccess = {
                                navController.navigate("scanner") {
                                    popUpTo("welcome") { inclusive = true }
                                }
                            },
                            onFailure = { error ->
                                Log.e("AccountTypeChoice", "Failed to save guest user", error)
                            }
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text(text = "📷 Scan QR Code to Join Event")
            }
        }
    }
}
