package com.example.wedsnap20.services

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.android.gms.auth.api.signin.*
import com.google.firebase.auth.*
import com.google.firebase.firestore.FirebaseFirestore

class AuthService(private val context: Context) {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    private val googleSignInClient: GoogleSignInClient by lazy {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(com.example.wedsnap20.R.string.default_web_client_id))
            .requestEmail()
            .build()
        GoogleSignIn.getClient(context, gso)
    }

    fun getSignInIntent(): Intent = googleSignInClient.signInIntent

    fun handleSignInResult(data: Intent?, onResult: (Result<FirebaseUser>) -> Unit) {
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.result
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)
            auth.signInWithCredential(credential)
                .addOnSuccessListener { result ->
                    onResult(Result.success(result.user!!))
                }
                .addOnFailureListener { e ->
                    onResult(Result.failure(e))
                }
        } catch (e: Exception) {
            onResult(Result.failure(e))
        }
    }

    fun getCurrentUser(): FirebaseUser? = auth.currentUser

    fun signInAnonymously(
        onSuccess: (FirebaseUser) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        auth.signInAnonymously()
            .addOnSuccessListener { result ->
                result.user?.let { user ->
                    onSuccess(user)
                } ?: onFailure(Exception("Anonymous user is null"))
            }
            .addOnFailureListener { error ->
                val fallback = auth.currentUser
                if (fallback != null && fallback.isAnonymous) {
                    Log.w("AuthService", "signInAnonymously failed but fallback user exists")
                    onSuccess(fallback)
                } else {
                    onFailure(error)
                }
            }
    }

    fun createOrUpdateUser(
        user: FirebaseUser,
        name: String,
        type: String, // "guest" or "host"
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val userData = mapOf(
            "uid" to user.uid,
            "name" to name,
            "type" to type,
            "createdAt" to System.currentTimeMillis()
        )

        FirebaseFirestore.getInstance()
            .collection("users")
            .document(user.uid)
            .set(userData)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it) }
    }

    fun getUserType(
        uid: String,
        onResult: (String?) -> Unit
    ) {
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val type = doc.getString("type")
                    onResult(type)
                } else {
                    onResult(null)
                }
            }
            .addOnFailureListener {
                onResult(null)
            }
    }

    fun isUserExists(
        uid: String,
        onResult: (Boolean) -> Unit
    ) {
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .get()
            .addOnSuccessListener { doc ->
                onResult(doc.exists())
            }
            .addOnFailureListener {
                onResult(false)
            }
    }
}
