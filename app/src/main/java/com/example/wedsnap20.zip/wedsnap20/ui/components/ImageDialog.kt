package com.example.wedsnap20.ui.components

import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.rememberAsyncImagePainter
import androidx.core.net.toUri
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.net.URL


@Composable
fun ImageDialog(
    imageUrls: List<String>,
    initialIndex: Int = 0,
    onDismiss: () -> Unit
) {
    var showFullScreen by remember { mutableStateOf(false) }
    val pageCount = imageUrls.size
    val pagerState = rememberPagerState(initialPage = initialIndex, pageCount = { pageCount })
    val currentIndex = pagerState.currentPage
    val context = LocalContext.current


    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp)
                .background(color = Color(0xFFFEF9EC), shape = RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                    ) { page ->
                        if (page < pageCount) {
                            Image(
                                painter = rememberAsyncImagePainter(imageUrls[page]),
                                contentDescription = null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showFullScreen = true },
                                contentScale = ContentScale.Fit
                            )
                        }
                    }
                    }

                if (showFullScreen) {
                    Dialog(onDismissRequest = { showFullScreen = false }) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable { showFullScreen = false },
                            contentAlignment = Alignment.Center
                        ) {
                            HorizontalPager(
                                state = pagerState,
                                modifier = Modifier.fillMaxSize()
                            ) { page ->
                                Image(
                                    painter = rememberAsyncImagePainter(imageUrls[page]),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }
                    }
                }


                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                ) {
                    TextButton(onClick = {
                        val url = imageUrls[currentIndex]
                        val request = DownloadManager.Request(url.toUri()).apply {
                            setTitle("WedSnap Photo")
                            setDescription("Downloading image...")
                            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, "wedsnap_${System.currentTimeMillis()}.jpg")
                            setAllowedOverMetered(true)
                        }

                        val downloadManager = context.getSystemService(DownloadManager::class.java)
                        downloadManager.enqueue(request)
                    }) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Download")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Download")
                    }

                    TextButton(onClick = {
                        CoroutineScope(Dispatchers.IO).launch {
                            try {
                                val imageUrl = imageUrls[currentIndex]
                                val input = URL(imageUrl).openStream()
                                val file = File(context.cacheDir, "shared_image_${System.currentTimeMillis()}.jpg")
                                file.outputStream().use { output -> input.copyTo(output) }

                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.provider",
                                    file
                                )

                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "image/jpeg"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }

                                context.startActivity(
                                    Intent.createChooser(shareIntent, "Share image via")
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }) {
                        Icon(Icons.Default.Share, contentDescription = "Share")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Share")
                    }



                    IconButton(onClick = { /* TODO: Like */ }) {
                        Icon(Icons.Filled.FavoriteBorder, contentDescription = "Like")
                    }
                }
            }
        }
    }
}
