package com.example.wedsnap20.ui

import android.app.Activity
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.wedsnap20.ui.util.LocalActivity
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult

@Composable
fun ScannerScreen(navController: NavHostController) {
    val activity = LocalActivity()
    var scannedText by remember { mutableStateOf<String?>(null) }
    var hasNavigated by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val intentResult: IntentResult = IntentIntegrator.parseActivityResult(
            result.resultCode, result.data
        )
        scannedText = intentResult?.contents ?: "Scan cancelled"
        if (!hasNavigated && !scannedText.isNullOrBlank() && scannedText != "Scan cancelled") {
            hasNavigated = true
            navController.navigate("guest_album/${scannedText}")
        }

    }

    LaunchedEffect(Unit) {
        val isEmulator = android.os.Build.FINGERPRINT.contains("emu")
        if (isEmulator) {
            if (!hasNavigated) {
                hasNavigated = true
                navController.navigate("guest_album/aa4f37ab")
            }
        } else {
            // Launch QR scanner once on real device
            val integrator = IntentIntegrator(activity)
            integrator.setOrientationLocked(true)
            integrator.setPrompt("Scan a QR code")
            launcher.launch(integrator.createScanIntent())
        }
    }


    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("QR Scan Result:", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(12.dp))
            Text(scannedText ?: "Waiting...", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
