package com.example.wedsnap20.ui.screens.host

import android.graphics.Bitmap
import android.graphics.Color
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.wedsnap20.model.Album
import com.example.wedsnap20.services.AlbumService
import com.example.wedsnap20.viewmodel.AuthViewModel
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import androidx.core.graphics.createBitmap
import androidx.core.graphics.set
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.wedsnap20.ui.components.AlbumListItem
import com.example.wedsnap20.ui.components.QRCodeDialog


enum class HostScreenState { Idle, Create, View }

@Composable
fun HostPanelScreen(viewModel: AuthViewModel) {
    val user = viewModel.userInfo.collectAsState().value
    val context = LocalContext.current
    val albumService = remember { AlbumService() }

    var screenState by remember { mutableStateOf(HostScreenState.Idle) }
    var albumName by remember { mutableStateOf(TextFieldValue("")) }
    var album by remember { mutableStateOf<Album?>(null) }
    var albums by remember { mutableStateOf<List<Album>>(emptyList()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Welcome, $user!", style = MaterialTheme.typography.titleMedium)

        Spacer(modifier = Modifier.height(32.dp))

        // Main options
        Button(onClick = { screenState = HostScreenState.Create }) {
            Text("Create New Album")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(onClick = {
            albumService.getAlbumsByHost {
                albums = it
                screenState = HostScreenState.View
            }
        }) {
            Text("View My Albums")
        }

        Spacer(modifier = Modifier.height(32.dp))

        when (screenState) {
            HostScreenState.Create -> {
                OutlinedTextField(
                    value = albumName,
                    onValueChange = { albumName = it },
                    label = { Text("Album Name") }
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(onClick = {
                    albumService.createAlbum(albumName.text) {
                        album = it
                    }
                }) {
                    Text("Confirm Create")
                }

                Spacer(modifier = Modifier.height(24.dp))

                album?.let {
                    Text("Event ID: ${it.eventId}")
                    Spacer(modifier = Modifier.height(16.dp))
                    QRCodeImage(content = it.eventId)
                }
            }

            HostScreenState.View -> {
                if (albums.isEmpty()) {
                    Text("No albums found.")
                } else {
                    Text("My Albums", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(12.dp))

                    var qrToShow by remember { mutableStateOf<String?>(null) }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 16.dp)
                    ) {
                        items(albums) { album ->
                            AlbumListItem(
                                album = album,
                                onQRCodeClick = { qrToShow = it }
                            )
                        }
                    }

                    qrToShow?.let {
                        QRCodeDialog(content = it, onDismiss = { qrToShow = null })
                    }

                }
            }

            HostScreenState.Idle -> { /* Show nothing */ }
        }
    }
}

@Composable
fun QRCodeImage(
    content: String,
    modifier: Modifier = Modifier
    ) {
    val size = 512
    val bitmap = remember(content) {
        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size)
        val bmp = createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bmp[x, y] =
                    if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
            }
        }
        bmp
    }
    Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = "QR Code",
        modifier = modifier
    )

}
