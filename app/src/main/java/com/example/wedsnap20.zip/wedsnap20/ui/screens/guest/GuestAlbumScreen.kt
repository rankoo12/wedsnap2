package com.example.wedsnap20.ui.screens.guest

import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.wedsnap20.services.AlbumService
import kotlinx.coroutines.launch

@Composable
fun GuestAlbumScreen(eventId: String, navController: NavController) {
    val context = LocalContext.current
    val albumService = remember { AlbumService() }
    val coroutineScope = rememberCoroutineScope()

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri>? ->
        uris?.forEach { uri ->
            coroutineScope.launch {
                Log.d("UPLOAD", "Selected URI: $uri")
                albumService.uploadImageToAlbum(eventId, uri, context)
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        bitmap?.let {
            coroutineScope.launch {
                albumService.uploadBitmapToAlbum(eventId, it, context)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Album: $eventId", style = MaterialTheme.typography.titleLarge)

        Button(onClick = { galleryLauncher.launch("image/*") }) {
            Log.d("UPLOAD", "Upload from gallery clicked")
            Text("Upload from Gallery")
        }

        Button(onClick = { cameraLauncher.launch(null) }) {

            Text("Take Photo")
        }

        Button(onClick = {
            // Optional: navigate to album viewing screen if different
            navController.navigate("guest_gallery/$eventId")
        }) {
            Text("View Album")
        }
    }
}
