package com.example.wedsnap20.ui.screens.host

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.example.wedsnap20.ui.ScannerScreen
import com.example.wedsnap20.ui.screens.AccountTypeChoiceScreen
import com.example.wedsnap20.ui.screens.guest.GuestAlbumScreen
import com.example.wedsnap20.ui.screens.guest.GuestDecisionScreen
import com.example.wedsnap20.ui.screens.guest.GuestGalleryScreen
import com.example.wedsnap20.viewmodel.AuthViewModel

@Composable
fun AppNavHost(
    navController: NavHostController,
    viewModel: AuthViewModel
) {
    NavHost(navController = navController, startDestination = "welcome") {
        composable("welcome") {
            WelcomeScreen(navController = navController)
        }
        composable("scanner") {
            ScannerScreen(navController = navController)
        }
        composable("host_panel") {
            HostPanelScreen(viewModel = viewModel)
        }
        composable("guest_album/{eventId}") { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId") ?: ""
            GuestAlbumScreen(eventId = eventId, navController = navController)
        }
        composable(
            route = "guest_gallery/{eventId}",
            arguments = listOf(navArgument("eventId") { type = NavType.StringType })
        ) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId") ?: ""
            GuestGalleryScreen(eventId = eventId)
        }

        // 🔜 Coming soon:
        // composable("guest_decision") { GuestDecisionScreen(...) }
        // composable("account_type_choice") { AccountTypeChoiceScreen(...) }
        composable("guest_decision") {
            GuestDecisionScreen(navController = navController)
        }

        composable("account_type_choice") {
            AccountTypeChoiceScreen(navController = navController)
        }

// Optional placeholder for future:
        composable("create_event") {
            //CreateEventScreen(navController = navController) // even if it's not yet implemented
        }

    }
}
