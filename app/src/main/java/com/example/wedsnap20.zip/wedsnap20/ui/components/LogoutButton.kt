package com.example.wedsnap20.ui.components

import android.util.Log
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth

@Composable
fun LogoutButton(navController: NavController) {
    val auth = FirebaseAuth.getInstance()

    Button(onClick = {
        auth.signOut()
        navController.popBackStack(navController.graph.startDestinationId, inclusive = true)
        navController.navigate("welcome")
        Log.d("LogoutCheck", "User after logout: ${auth.currentUser?.uid}")
    }) {
        Text("Logout")
    }
}
