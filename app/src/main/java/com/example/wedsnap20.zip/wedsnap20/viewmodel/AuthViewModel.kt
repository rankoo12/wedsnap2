package com.example.wedsnap20.viewmodel

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.wedsnap20.services.AuthService
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val authService = AuthService(application)

    private val _userInfo = MutableStateFlow<Pair<String?, String?>?>(null)
    val userInfo = _userInfo.asStateFlow()

    fun getSignInIntent(): Intent {
        return authService.getSignInIntent()
    }

    fun handleSignInResult(data: Intent?) {
        authService.handleSignInResult(data) { result ->
            viewModelScope.launch {
                result.onSuccess { user: FirebaseUser ->
                    _userInfo.value = Pair(user.displayName, user.email)
                }.onFailure {
                    _userInfo.value = Pair("Sign-in failed",null)
                }
            }
        }
    }
}
