package com.example.wedsnap20.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.wedsnap20.ui.screens.host.QRCodeImage

@Composable
fun QRCodeDialog(
    content: String,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = { /* TODO: share */ }) {
                    Text("Share")
                }
                TextButton(onClick = { /* TODO: download */ }) {
                    Text("Download")
                }
            }
        },
        title = { Text("QR Code") },
        text = {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                QRCodeImage(content = content)
            }
        }
    )
}
